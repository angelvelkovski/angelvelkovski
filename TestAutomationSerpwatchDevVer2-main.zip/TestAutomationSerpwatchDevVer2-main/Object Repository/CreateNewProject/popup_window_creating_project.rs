<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>popup_window_creating_project</name>
   <tag></tag>
   <elementGuidId>2987fb8a-e47d-4644-bfae-25bf6298fd1b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='create-project-form']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#create-project-form > div.modal-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-content</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

Send feedback























SerpWatch Charges Based on Keyword checks usage

Purchased
--------------------------
4500


Used
--------------------------
0


Forecast
--------------------------
72


Left
--------------------------
4428








Changing your check frequency will affect your keyword check usage, i.e. the more frequently you check, the fewer checks you will have available to spend per month. Learn more


4.4K
checked 
once monthly


1.0K
checked 
once weekly


442
checked 
once 3 days


147
checked 
once daily


73
checked every
12 hours


36
checked every
6 hours


12
checked every
2 hours


6
checked 
hourly



 Upgrade Now


Learn more




                    $('#btn-toggle-keyword-balance-popup').click();

                    if ($(window).width() > 767) {
                        var dropdownClose = false;
                        $(&quot;.hold-transition&quot;).on('click keydown', function (ev) {
                            let keyCode = ev.keyCode || ev.which;
                            dropdownClose = keyCode === 9;
                        });

                        $('.hold-transition').on('hide.bs.dropdown', function (e) {
                            if (e.clickEvent || dropdownClose)
                                e.preventDefault();
                        });
                    }
                


create Project











































Project name







Domain








 Add Competitor



Add your keywords







UPLOAD FROM CSV







Keywords suggestions









Here you will see keyword suggestions





Send feedback

or


Connect To Google Search Console







Select Check Frequency
Send feedback







Monthly





Weekly





3 days





Daily





12 hours





6 hours





2 hours





Hourly







Next








Setup Engine and Location
Send feedback









Combo #1




              
                  
                  yandex.com
              
              
                        
                            
                            
                        
                    
                    
                        
                            
                            
                        
                    
                
        
              
                  
                  search.yahoo.com
              
              
                        
                            
                            
                        
                    
                        
                            
                            
                        
                    
        
              
                  
                  google.com
              
              
                        
                            
                            
                        
                    
                        
                            
                            
                        
                    
        
              
                  
                  bing.com
              
              
                        
                            
                            
                        
                    
                        
                            
                            
                        
                    
        









Country













EnglishAll LanguagesVietnameseSwedishSpanishRussianPortuguese (Portugal)NorwegianKoreanGermanFrenchEspanol (Latinoamerica)DutchDanishChinese (Traditional)Chinese (Simplified)Arabic
Language












Postal Code













Track local results












Add a location &amp; search engine






Next










Setup Notifications, Integrations and Automation



Notifications
(These settings can be updated for each keyword)








Slack webhook







Add to Slack






Test connection






Help guide










Send feedback




Push Notifications




Please 'Allow' notifications in browser.










Email








Test email















Zapier webhook








Send sample to Zapier






Test Zapier






Help guide














Advanced Notification Settings



Integrations
















Automations













create Project



 Upgrade Now













Project Notification Settings




Enable alerts for all of project's keywords





Position Rise

5 positions




Position Fall

2 positions






Keyword Hits All-Time High






Monitor Swings






Email Notifications Frequency





this setting will be applied on all of your projects




Hourly
Daily










Drastic Drop

3 times






Featured Snippet






Cannibalization Detection


Send feedback





Done








            var projectAlert = &quot;0&quot;,
            emailAddress = &quot;&quot;,
            userEmail = 'ayatullah.arul@gmail.com',
            emailAlert = &quot;0&quot;,
            slackHook = &quot;&quot;,
            slackAlert = &quot;0&quot;,
            zapierHook = &quot;&quot;,
            zapierAlert = &quot;0&quot;,
            webPushAlert = &quot;0&quot;,
            positionRise = &quot;5&quot;,
            positionFall = &quot;2&quot;,
            hitsHigh = &quot;0&quot;,
            drasticTesting = &quot;0&quot;,
            drasticDrop = &quot;2&quot;,
            featuredSnippet = &quot;0&quot;,
            cannibalizationDetection = &quot;0&quot;,
            emailFrequency = &quot;&quot;,
            emailTimePick = &quot;06:09:00&quot;;
    








Send feedback
API details 





API Email





API Password





Regenerate API Password








 








Send feedback

Click Here to connect your Google Analytics account.



 



Done








    .absolute-close.closeGoogleAnalytics {
        top: -37px !important;
        background: #dddfeb !important;
    }






Checks usage : 4500




1.6%



72



</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;create-project-form&quot;)/div[@class=&quot;modal-content&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='create-project-form']/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='next'])[1]/following::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='skip'])[1]/following::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/form/div</value>
   </webElementXpaths>
</WebElementEntity>
