<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_click_to_upload</name>
   <tag></tag>
   <elementGuidId>6f4e3c71-60d3-4605-b0e8-38b7c3622bd3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.csv-upload-file-container.d-flex.h-100.align-items-center.justify-content-center.btn-purple.rounded-sm-left.p-5.p-sm-0</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='importCsvKeywordsModal']/div/div/div[2]/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>csv-upload-file-container d-flex h-100 align-items-center justify-content-center btn-purple rounded-sm-left p-5 p-sm-0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>



Drag or click to upload file

</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;importCsvKeywordsModal&quot;)/div[@class=&quot;modal-dialog modal-dialog-centered modal-lg modal-k-e&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body p-0&quot;]/div[@class=&quot;import-button-container row no-gutters&quot;]/div[@class=&quot;col-md-6 text-center&quot;]/div[@class=&quot;csv-upload-file-container d-flex h-100 align-items-center justify-content-center btn-purple rounded-sm-left p-5 p-sm-0&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='importCsvKeywordsModal']/div/div/div[2]/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Import from CSV'])[1]/following::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download report'])[1]/following::div[8]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='.csv'])[1]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div/div/div[2]/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
