<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Login Positive Test Suites</description>
   <name>LoginPositiveTestSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>993870ed-7d25-4dfd-9341-46860b889af8</testSuiteGuid>
   <testCaseLink>
      <guid>bf4e768a-07fe-4957-9674-de19167ed8bd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/RegisterAndLogin/Positive/TS-LGN-4-LoginThroughTheAppTestCase</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
